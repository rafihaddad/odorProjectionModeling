
load Data/OB_data.mat %%the original database of evoked spike count for anesthetized and awake case

%% th= threshold, K=synaptic degree, cm= connectivity matrix through which 
%% PC neurons integrates from OB neurons.

colorspec = {[1 0 1];[0 1 1];[0.48 0.06 0.89];[0.87 0.49 0];[0.6 0.2 0];[1  0.69 0.39]};
repeatN=100;

    OBx=BoldingOB;
    
    %th=8;
    th_sy=[2,4,8,12];
    OB_population_sparseness_exp=0.5115; %Population sparseness in OB from data (absolute responses)
    PC_Cor_exp=0.5359;        %%%Odor pairwise mean correlation in PC from data
    PC_population_sparseness_exp=0.7047; %%Population sparseness in PC from data (Absolute responses)
%end

Nx=size(OBx,1);            %number of OB neurons
No=size(OBx,2);              % number of odors
Ny=Nx;  
%me_W=[1,2,5,10];

LegendsStringsK = cell(length(th_sy),1);
%LegendsStringsW = cell(length(me_W),1);
OBcor=corr(OBx);
OB_Corr=OBcor(triu(true(size(OBcor)), 1));

for ii=1:length(th_sy)
    
%    mean_W=me_W(ii);
    th_synp=th_sy(ii);
    mean_PCCor_varK=[];
  %  mean_PCCor_varW=[];
for K_percentage=1:2:11 % percentage of average number of connection
    stdK=K_percentage*Nx/100; %average number of connection

     PC_count_varK=[];
 %    PC_count_varW=[];
 for count=1:repeatN   %%% number of repeatation 
     
%%%%%%%%%%%%%%%%%%%%%%%%%% synaptic degree K %%%%%%%%%%%%%%%%%
%%%%%% each PC neurons integrates from K random OB neurons
conect=ceil(exprnd(stdK,1,Ny+40));

index11=find(conect<Ny); %%to ensure that there is no synaptic degree > number of neurons
syn_degre=conect(index11);
%weight=(abs(normrnd(mean_W,std_W,Ny,K)));
% weight=exprnd(mean_W,Ny,K);
  cm_varK=zeros(Ny,Nx); 
%  cm_varW=zeros(Ny,Nx);

 for i=1:Ny
     cm_varK(i,randperm(Ny,syn_degre(i)))=1; %unweighted put weight for weighted
 end

PCy_varK=cm_varK*OBx;

%%%%%%%%%%% make 0 to those <Th
%  index_varK=find(PCy_varK<=th_synp);
%  PCy_varK(index_varK)=0;

%%%%%%%%%%%%%% make PCy-Th and make 0 to those <0
 PCy_varK=PCy_varK-th_synp;
 index=find(PCy_varK<=0);
 PCy_varK(index)=0;


 tempsort = sort(PCy_varK,'descend');
     maxy = full(tempsort( round(.01*length(tempsort)) ));
     PCy_varK=PCy_varK/maxy;
PCcorr_varK=corr(PCy_varK);
PC_Cor_varK=PCcorr_varK(triu(true(size(PCcorr_varK)), 1));
  id1=find(PC_Cor_varK(:,1)<=1); % number of non nan correlation.
%  
  if length(id1)>=0.7*size(PC_Cor_varK,1)
      PC_Cor1_varK=PC_Cor_varK(id1);
  else 
      PC_Cor1_varK=PC_Cor_varK;
  end
    
    [odorsSparsenessTR_varK] = populationSparsenessTRInRegion(PCy_varK); %%calculating the population sparseness
    [neuronsSparsenessTR_varK] = lifetimeSparsenessTRInRegion(PCy_varK);  %%calculating the lifetime sparseness
    PC_count_varK=[PC_count_varK;mean(PC_Cor1_varK),mean(odorsSparsenessTR_varK),mean(neuronsSparsenessTR_varK)];


    
end

mean_PCCor_varK=[mean_PCCor_varK;th_synp, K_percentage,mean(PC_count_varK(:,1)),mean(PC_count_varK(:,2)),mean(PC_count_varK(:,3))];
% mean_PCCor_varW=[mean_PCCor_varW;th, K,mean(PC_count_varW(:,1)),mean(PC_count_varW(:,2)),mean(PC_count_varW(:,3))];

end
 
subplot(1,2,1)
plot(mean_PCCor_varK(:,2),mean_PCCor_varK(:,3)-mean(OB_Corr),'Color', colorspec{ii})
hold on
LegendsStringsK{ii} = ['T = ',num2str(th_sy(ii))];
subplot(1,2,2)
plot(mean_PCCor_varK(:,2),mean_PCCor_varK(:,4),'Color', colorspec{ii})
hold on




end

subplot(1,2,1)
plot([0,K_percentage],[PC_Cor_exp-mean(OB_Corr),PC_Cor_exp-mean(OB_Corr)],'k--')
%plot([0,K],[PC_Cor_exp,PC_Cor_exp],'g');    %%%%%%% PC correlation from experiment
set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
xlabel('K(%)~exp(1/\lambda)','fontsize',10)
ylabel('<PC> - <OB> correlation','fontsize',10);

legend(LegendsStringsK, 'Interpreter', 'tex')

subplot(1,2,2)
plot([0,K_percentage],[PC_population_sparseness_exp,PC_population_sparseness_exp],'b--')
plot([0,K_percentage],[OB_population_sparseness_exp,OB_population_sparseness_exp],'r--')
set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
xlabel('K(%)~exp(1/\lambda)','fontsize',10)
ylabel('Sparser','fontsize',10);

set(gcf,'color','w')   