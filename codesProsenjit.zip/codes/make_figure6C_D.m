
load Data/OB_data.mat %%the original database of evoked spike count for anesthetized and awake case

%% th= threshold, K=synaptic degree, cm= connectivity matrix through which 
%% PC neurons integrates from OB neurons.

colorspec = {[1 0 1];[0 1 1];[0.48 0.06 0.89];[0.87 0.49 0];[0.6 0.2 0];[1  0.69 0.39]};
repeatN=100;


%
    OBx=BoldingOB;
       
    me_T=[ 8, 8,24,24]; %average threshold values
    st_T=[ 5,10,5,10]; % std of threshold values
    OB_Cor_exp=0.4119; %OB correlation from experiment
    OB_population_sparseness_exp=0.5115; %Population sparseness in OB from data (absolute responses)
    PC_Cor_exp=0.5359;        %%%Odor pairwise mean correlation in PC from data
    PC_population_sparseness_exp=0.7047; %%Population sparseness in PC from data (Absolute responses)


Nx=size(OBx,1);            %number of OB neurons
No=size(OBx,2);             % number of odors
Ny=10*Nx;       
LegendsStrings = cell(length(me_T),1);

OBcor=corr(OBx);
OB_Corr=OBcor(triu(true(size(OBcor)), 1));

for ii=1:length(me_T)
    mean_T=me_T(ii);
    std_T=st_T(ii);
    mean_PCCor=[];
    
for K_percentage=1:4:21
    K=round(K_percentage*Nx/100);
     PC_count=[];
 for count=1:repeatN   %%% number of repeatation 
     
%%%%%%%%%%%%%%%%%%%%%%%%%% synaptic degree K %%%%%%%%%%%%%%%%%
%%%%%% each PC neurons integrates from K random OB neurons
th=normrnd(mean_T,std_T,Ny,No);
  cm=zeros(Ny,Nx); 
 for i=1:Ny
     cm(i,randperm(Nx,K))=1; %unweighted put weight for weighted
 end

%%%%%%%%%%%%%piriform neuron response
%%%compute the transformation by the multiplication of the transformation 
%%%matrix through which the mixed layer neurons integrate and evoked spike
%%%count of the input layer 
%PCy=cm*OBx+bsl;
PCy=cm*OBx;

%%%%%%%%%%% make 0 to those <Th
% index=find(PCy<=th);
% PCy(index)=0;

%%%%%%%%%%%%%% make PCy-Th and make 0 to those <0
PCy=PCy-th;
index=find(PCy<=0);
PCy(index)=0;

tempsort = sort(PCy,'descend');
    maxy = full(tempsort( round(.01*length(tempsort)) ));
    PCy=PCy/maxy;
PCcorr=corr(PCy);
PC_Cor=PCcorr(triu(true(size(PCcorr)), 1));


  id1=find(PC_Cor(:,1)<=1); % number of non nan correlation.
%  
  if length(id1)>=0.7*size(PC_Cor,1)
      PC_Cor1=PC_Cor(id1);
  else 
      PC_Cor1=PC_Cor;
  end
     
    [odorsSparsenessTR] = populationSparsenessTRInRegion(PCy); %%calculating the population sparseness
    [neuronsSparsenessTR] = lifetimeSparsenessTRInRegion(PCy);  %%calculating the lifetime sparseness
   PC_count=[PC_count;mean(PC_Cor1),mean(odorsSparsenessTR),mean(neuronsSparsenessTR)];

    
end

mean_PCCor=[mean_PCCor;mean_T, K_percentage,mean(PC_count(:,1)),mean(PC_count(:,2)),mean(PC_count(:,3))];

end
 
subplot(1,2,1)
plot(mean_PCCor(:,2),mean_PCCor(:,3)-mean(OB_Corr),'Color', colorspec{ii})
hold on
LegendsStrings{ii} = ['T \in N( ',num2str(me_T(ii)),',',num2str(st_T(ii)),')'];
subplot(1,2,2)
plot(mean_PCCor(:,2),mean_PCCor(:,4),'Color', colorspec{ii})
hold on

end

subplot(1,2,1)
plot([0,K_percentage],[PC_Cor_exp-mean(OB_Corr),PC_Cor_exp-mean(OB_Corr)],'k--')
    %%%%%%% PC correlation from experiment
set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
xlabel('K(%)','fontsize',10)
ylabel('<PC> - <OB> correlation','fontsize',10);
legend(LegendsStrings, 'Interpreter', 'none')


subplot(1,2,2)
plot([0,K_percentage],[PC_population_sparseness_exp,PC_population_sparseness_exp],'b--')
plot([0,K_percentage],[OB_population_sparseness_exp,OB_population_sparseness_exp],'r--')

set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
xlabel('K(%)','fontsize',10)
ylabel('Sparser','fontsize',10);

set(gcf,'color','w')   