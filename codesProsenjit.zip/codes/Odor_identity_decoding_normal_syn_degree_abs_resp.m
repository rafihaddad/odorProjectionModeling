%% parameters

% a=randi(size(decodingOBMor,1),size(decodingOBMor,1),1);
% 
%  for i=1:20
%  for j=1:size(decodingOBMor,1)
%  decodingOBmorSuffled(j,:,i)=decodingOBMor(a(j),:,i);
% 
% %  OB=decodingOBMor(a);
% %  OBx=reshape(OB(randperm(101*9)),101,9);
% %  decodingOBmorSuffled(:,:,i)=OBx;
%  end
% end
%load Data/decodingOBBolding.mat
load Data/OB_Bolding_abs_spike_count_2_sniffs.mat

%OBx=decodingOBBolding;
OBx=OB;

Nx=size(OBx,1);            %number of OB neurons
No=size(OBx,2);              % number of odors
Nr=size(OBx,3);                % number of iteration
Ny=Nx*10;             %number of PC neurons
%bsl=1.72;           %baseline activity for PC
th=12;
%mean_K=20;
data_T_K_W=[];
for mean_K=[2,4,8,12]
    
for sig1_percentage=1:4:21
%for sig1=1:5:51
sig1=sig1_percentage*Nx/100;
stdK=sig1;
%%%%%%%%%%%%%%%%      normally distributed K   %%%%%%%%%%%%%%%%%
count_accuracy=[];
for count1=1:20%:20
%%%%%Connectivity matrix 
 cm=zeros(Ny,Nx);
  conect_ex=ceil(abs(normrnd(mean_K,stdK,1,Ny+500))); 
conect_inh=ceil(abs(normrnd(2*mean_K,stdK,1,Ny+500))); %% normal



%index11=find(conect_ex<Nx-Nx*ScInh); %%to ensure that there is no synaptic degree > number of neurons
%index11=find(conect<Nx-Nx*Sc);
index11=find(conect_ex+conect_inh<Nx);

syn_degre_ex=conect_ex(index11);
syn_degre_inh=conect_inh(index11);
%  for i=1:Ny
%      cm(i,randperm(Nx,syn_degre(i)))=1; %unweighted put weight for weighted
%  end
 for i=1:Ny
     input_ex=randperm(Nx,syn_degre_ex(i));
         %input_inh=randperm(Nx,syn_degre(i));

         input_in_con=setdiff([1:Nx],input_ex);
        % inhib_con=randperm(length(input_in_con),Nx*ScInh);
         
         inhib_con=randperm(length(input_in_con),syn_degre_inh(i));
     cm(i,input_ex)=1; %unweighted put weight for weighted
     cm(i,input_in_con(inhib_con))=-0.5;    
 end

%%%%%%%%%%%%%%%%%%%%% synaptic degree 1     %%%%%%%%%%%%%%


  PC_count=[];
  for count=1:Nr
   

%PCy=cm*OBx-th;
PCy=cm*OBx(:,:,count);
%PCy=PCy1+bsl;

%%%%%%%%%%% make 0 to those <Th
% index=find(PCy<=th);
% PCy(index)=0;

%%%%%%%%%%%%%% make PCy-Th and make 0 to those <0
PCy=PCy-th;
index=find(PCy<=0);
PCy(index)=0;
decodingPC(:,:,count)=PCy;
  end





mat_FR = decodingPC;       % response matrix: #neurons x #odors x #trials
% std = nanstd(mat_FR,0,3);
% avg = nanmean( mat_FR,3);
% CV = std./avg;
% CV1=rmmissing(CV(:));
%pCV1 = CV1';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%for decoding
num_odors = 6;                  % # odors to decode
num_neurons_array =100;  % array of number of neurons to use in each run
maxTrialNum = 15;               % # trials to use in decoding
dist = 'Euclidean';             %  distance type for odor decoding
num_rep = 50;                  % number of bootstrapping repetitions
%% run decoding with different number of neurons
meanSuccessRate = NaN(1,length(num_neurons_array));
sdSuccessRate = NaN(1,length(num_neurons_array));
for nn = 1:length(num_neurons_array)
    num_neurons = num_neurons_array(nn);
    successRateAll = NaN(1,num_rep);
    for rep=1:num_rep
        % choose random num_neurons neurons and num_odors odors
        neurons = randperm(size(mat_FR,1),min(num_neurons,size(mat_FR,1)));
        odors = randperm(size(mat_FR,2),num_odors);
         % create samples of labels and features
        decoding_data = struct();
        sample_size = length(neurons)*length(odors);
        labels = NaN(1,sample_size); decoding_data(1,sample_size) = struct(); kk=1;
        labelIDs = odors;
        for ii=neurons
            for jj=odors
                labels(kk) = jj;
                fr = squeeze(mat_FR(ii,jj,:));
                fr = fr(~isnan(fr));
                decoding_data(kk).features = fr;
                kk = kk + 1;
            end
        end  
        % run decoding: calculate success rate of decoding
        successRateAll(rep) =  generalLeav1OutDecoder(labels, decoding_data, labelIDs, maxTrialNum, dist);
    end
    %% 
    successRateAll = successRateAll * 100;
    % mean & standard deviation across bootstrapping repetitions of success rates
    meanSuccessRate(nn) = mean(successRateAll);
    sdSuccessRate(nn) = std(successRateAll); 
end
count_accuracy=[count_accuracy;meanSuccessRate,sdSuccessRate];
end
data_T_K_W=[data_T_K_W;mean_K, sig1,sig1_percentage, mean(count_accuracy(:,1)),mean(count_accuracy(:,2))];
end
end
 
save data_T_K_W_varysyn_normal_100neuronsT_subtraction_abs1to21_t12_2sniff.mat data_T_K_W
errorbar(data_T_K_W(1:6,3),data_T_K_W(1:6,4),data_T_K_W(1:6,5))
hold on
errorbar(data_T_K_W(7:12,3),data_T_K_W(7:12,4),data_T_K_W(7:12,5))
errorbar(data_T_K_W(13:18,3),data_T_K_W(13:18,4),data_T_K_W(13:18,5))
errorbar(data_T_K_W(19:24,3),data_T_K_W(19:24,4),data_T_K_W(19:24,5))
%%%setting the upper and lower line from experimental data of absolute
%%%responses 3 sniff
% plot([0 21],[78.038 78.038],'b--')
% plot([0 21],[91.582  91.582 ],'b--')
% plot([0 21],[97.7764  97.7764 ],'r--')
% plot([0 21],[99.6436 99.6436],'r--')

plot([0 21],[81.438 81.438],'b--')
plot([0 21],[93.862  93.862 ],'b--')
plot([0 21],[97.65  97.65 ],'r--')
plot([0 21],[99.67 99.67],'r--')
set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
%errorbar(data_T_K_W(:,1), data_T_K_W(:,2), data_T_K_W(:,3));

%figure();
%errorbar(num_neurons_array, meanSuccessRate, sdSuccessRate);
%ylim([0 100]);
  