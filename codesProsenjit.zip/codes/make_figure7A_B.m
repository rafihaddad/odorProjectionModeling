
load Data/OB_data.mat %%the original database of evoked spike count for anesthetized and awake case
%To use the absolute responses uncomment the following lines and use %OBx=OB_OdorResponse;
% load Bolding_OB_first_sniff_spike_count_odor_and_blank.mat
% load Bolding_PC_first_sniff_spike_count_odor_and_blank.mat
% pcdata_cor=corr(PC_OdorResponse);
% PC_Cor_data=pcdata_cor(triu(true(size(PCcorr)), 1));
%% th= threshold, K=synaptic degree, cm= connectivity matrix through which 
%% PC neurons integrates from OB neurons.
colorspec = {[1 0 1];[0 1 1];[0.48 0.06 0.89];[0.87 0.49 0];[0.6 0.2 0];[1  0.69 0.39]};
repeatN=100;

    %OBx=OB_OdorResponse;
    OBx=BoldingOB;
    
    me_K_percentage=[2,4, 8,12];
    %th=16;
    th_synp=12;
    OB_Cor_exp=0.4119;
    OB_population_sparseness_exp=0.5115; %Population sparseness in OB from data (Evoked responses)
    PC_Cor_exp=0.5359;        %%%Odor pairwise mean correlation in PC from data
%     PC_Cor_exp= mean(PC_Cor_data);
    PC_population_sparseness_exp=0.7047; %%Population sparseness in PC from data (Absolute responses)
%end

Nx=size(OBx,1);            %number of OB neurons
No=size(OBx,2);              % number of odors
Ny=10*Nx;  
% me_W=[2,2,5,5];
% st_W=[4,8,4,8];
LegendsStringsK = cell(length(me_K_percentage),1);
LegendsStringsW = cell(length(me_K_percentage),1);
OBcor=corr(OBx);
OB_Corr=OBcor(triu(true(size(OBcor)), 1));

for ii=1:length(me_K_percentage)
    mean_K=(me_K_percentage(ii)*Nx/100);
%     mean_W=me_W(ii);
%     std_W=st_W(ii);
    mean_PCCor_varK=[];
   % mean_PCCor_varW=[];
for K_percentage=1:4:21
    stdK=(K_percentage*Nx/100);
    
     PC_count_varK=[];
     PC_count_varW=[];
 for count=1:repeatN   %%% number of repeatation 
     
%%%%%%%%%%%%%%%%%%%%%%%%%% synaptic degree K %%%%%%%%%%%%%%%%%
%%%%%% each PC neurons integrates from K random OB neurons
%stdK=K;
conect=ceil(abs(normrnd(mean_K,stdK,1,Ny+50))); 
index11=find(conect<Nx); %%to ensure that there is no synaptic degree > number of neurons
syn_degre=conect(index11);
%weight=(abs(normrnd(mean_W,std_W,Ny,K)));
  cm_varK=zeros(Ny,Nx); 
 % cm_varW=zeros(Ny,Nx);

 for i=1:Ny
     cm_varK(i,randperm(Nx,syn_degre(i)))=1; %unweighted put weight for weighted
 end
 %  
%   for i=1:Ny
%       cm_varW(i,randperm(Nx,K))=weight(i,:); %unweighted put weight for weighted
%   end

%%%%%%%%%%%%%piriform neuron response
%%%compute the transformation by the multiplication of the transformation 
%%%matrix through which the mixed layer neurons integrate and evoked spike
%%%count of the input layer 
%%PC NEURONS FOR VARIABLE SYNAPTIC DEGREE
%PCy_varK=cm_varK*OBx+bsl;
PCy_varK=cm_varK*OBx;
%%%%%%%%%%% make 0 to those <Th
%  index_varK=find(PCy_varK<=th_synp);
%  PCy_varK(index_varK)=0;

%%%%%%%%%%%%%% make PCy-Th and make 0 to those <0
 PCy_varK=PCy_varK-th_synp;
 index=find(PCy_varK<=0);
 PCy_varK(index)=0;



% normalizing_ 99percentile
  tempsort = sort(PCy_varK,'descend');
     maxy = full(tempsort( round(.01*length(tempsort)) ));
     PCy_varK=PCy_varK/maxy;
    
PCcorr_varK=corr(PCy_varK);
PC_Cor_varK=PCcorr_varK(triu(true(size(PCcorr_varK)), 1));
  id1=find(PC_Cor_varK(:,1)<=1); % number of non nan correlation.
%  
  if length(id1)>=0.7*size(PC_Cor_varK,1)
      PC_Cor1_varK=PC_Cor_varK(id1);
  else 
      PC_Cor1_varK=PC_Cor_varK;
  end


     
    [odorsSparsenessTR_varK] = populationSparsenessTRInRegion(PCy_varK); %%calculating the population sparseness
    [neuronsSparsenessTR_varK] = lifetimeSparsenessTRInRegion(PCy_varK);  %%calculating the lifetime sparseness
    PC_count_varK=[PC_count_varK;mean(PC_Cor1_varK),mean(odorsSparsenessTR_varK),mean(neuronsSparsenessTR_varK)];

    
end

mean_PCCor_varK=[mean_PCCor_varK;th_synp, K_percentage,mean(PC_count_varK(:,1)),mean(PC_count_varK(:,2)),mean(PC_count_varK(:,3))];
%mean_PCCor_varW=[mean_PCCor_varW;th, K,mean(PC_count_varW(:,1)),mean(PC_count_varW(:,2)),mean(PC_count_varW(:,3))];

end
 
subplot(1,2,1)
plot(mean_PCCor_varK(:,2),mean_PCCor_varK(:,3)-mean(OB_Corr),'Color', colorspec{ii})
hold on
LegendsStringsK{ii} = ['<K> = ',num2str(me_K_percentage(ii)),'%'];
subplot(1,2,2)
plot(mean_PCCor_varK(:,2),mean_PCCor_varK(:,4),'Color', colorspec{ii})
hold on




end

subplot(1,2,1)
%plot([0,K_percentage],[mean(OB_Corr),mean(OB_Corr)],'r')
plot([0,K_percentage],[PC_Cor_exp-mean(OB_Corr),PC_Cor_exp-mean(OB_Corr)],'k--');    %%%%%%% PC correlation from experiment
set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
xlabel('std(K)','fontsize',10)
ylabel('Correlation','fontsize',10);
legend(LegendsStringsK, 'Interpreter', 'none')


subplot(1,2,2)
plot([0,K_percentage],[PC_population_sparseness_exp,PC_population_sparseness_exp],'b--')
plot([0,K_percentage],[OB_population_sparseness_exp,OB_population_sparseness_exp],'r--')
set(gca,'TickDir','out')
a=gca;
set(a,'box','off','color','none')
xlabel('std(K)','fontsize',10)
ylabel('Population sparseness','fontsize',10);



set(gcf,'color','w')   