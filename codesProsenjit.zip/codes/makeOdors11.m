function [x,similarity,overlap] = makeOdors11(value,No)
global Nx Sx glomExpMean glomExpMin glomExpMax templateOdor glomActMu glomActSig
%initializeGlobals;

similarity = ones(1,No);
overlap = nan(1,No);

%strcmp(kind,'correlated')
    %pMat = [ones( round(fracClassGlom*Sx*Nx), No); cVal*ones( round((1-fracClassGlom*Sx)*Nx), No)];
    if length(value)==1
        fracClassGlom = value;
        cVal = (1-fracClassGlom)*Sx/(1 - fracClassGlom*Sx);
        pMat = [ones( round(fracClassGlom*Sx*Nx), No); cVal*ones( Nx-round(fracClassGlom*Sx*Nx), No)];
        similarity = value*ones(1,No);
    else
        pMat = nan(Nx,No);
        similarity = nan(1,No);
        for j=1:length(value)
            if j==1
                fracClassGlom = value(2,1);
            else
                fracClassGlom = value(j-1,j);
            end
            cVal = (1-fracClassGlom)*Sx/(1 - fracClassGlom*Sx);
            pMat(:,j) = [ones( round(fracClassGlom*Sx*Nx), 1); cVal*ones( Nx-round(fracClassGlom*Sx*Nx), 1)];
            similarity(j) = fracClassGlom;
        end
%    end
    xtmp = rand(Nx,No) < pMat;
    x = makeXmagnitudes(xtmp,No,Nx,glomExpMax,glomActMu,glomActSig,value);
end



    



