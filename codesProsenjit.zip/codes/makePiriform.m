
function [y,th,h,J,maxy,thNoNorm] = makePiriform(x,pirSparseness,J,maxy,computeJ,th)
global Nx Ny Sc ScInh exInhBalance Sp glomActMu glomActSig thMean mean_K std_K mean_K_inh


if nargin<6
    th = thMean;
    useExactTh = true;
else
    useExactTh = false;
end
if ~exist('pirSparseness','var')
    pirSparseness=Sp;
elseif isempty(pirSparseness)
    pirSparseness=Sp;
end


conect_ex=round(abs(normrnd(mean_K,std_K,1,Ny+1500))); 
conect_inh=round(abs(normrnd(mean_K_inh,std_K,1,Ny+1500))); %% normal



%index11=find(conect_ex<Nx-Nx*ScInh); %%to ensure that there is no synaptic degree > number of neurons
%index11=find(conect<Nx-Nx*Sc);
index11=find(conect_ex+conect_inh<Nx);

syn_degre_ex=conect_ex(index11);
syn_degre_inh=conect_inh(index11);
J=zeros(Ny,Nx);

 
     for i=1:Ny
         input_ex=randperm(Nx,syn_degre_ex(i));
         %input_inh=randperm(Nx,syn_degre(i));

         input_in_con=setdiff([1:Nx],input_ex);
        % inhib_con=randperm(length(input_in_con),Nx*ScInh);
         
         inhib_con=randperm(length(input_in_con),syn_degre_inh(i));
%          input_ex_con=setdiff([1:Nx],input_inh);
%          ex_con=randperm(length(input_ex_con),Nx*Sc);
         
       %  input_ex=round((length(inputs_all))/3);
         %J(i,randperm(Nx,syn_degre(i)))=1; %for excitatory
         
         % J(i,input_ex)=2*rand(1,length(input_ex));
          J(i,input_ex)=1;
          J(i,input_in_con(inhib_con))=-0.5;
        % J(i,input_inh)=-0.5;
        % J(i,input_ex_con(ex_con))=1;         
     end

%%%%%%%%%% WEIGHTED EXCITATORY CONNECTION

% J=rand(Ny,Nx);
% index=find(J>0.2);
% ex_index=find(J<=0.2);
% J(index)=0;
% J(ex_index)=2*rand(length(ex_index),1);
% free_node=find(J==0);
% inhib_position=randperm(length(free_node),Ny*Nx*ScInh);
% J(free_node(inhib_position))=-0.5;

    y = J*x;

h = NaN;
sz = size(y);
No = sz(2);

if Ny<=10000 && useExactTh
    temp = sort(reshape(y,sz(1)*sz(2),1),'descend');
    temp2 = zeros(size(temp));
    temp2(1)=temp(1);
    for j=2:length(temp2)
        temp2(j)=temp2(j-1)+temp(j);
    end
    temp2(temp<0)=inf; %prevents following line from choosing -th instead of th
    [~,loc] = min(abs(temp2-temp2(round(Ny*pirSparseness*No))/.95)); % --> 10% cutoff accounts for 95% of total
    thCheck = temp(loc); %sum of first Sx fraction of responses / .95 = target
    display(['Threshold = ',num2str(th), ' = ', num2str( th/exp(glomActMu+glomActSig^2/2) ), ' avg glom inputs. Exact value for ',num2str(100*Sp),'% = ',num2str(thCheck) ] )
    
    if Ny<=10000
        th = thCheck;
        display('using exact theta for small Ny')
    end
    
end

if ~exist('maxy','var') || isempty(maxy)
    
    % instead of normalizing to largest value, normalize to 99th percentile
    % for greater stability of results
    tempsort = sort(y,'descend');
    maxy = full(tempsort( round(.01*length(tempsort)) ));
end

y = y-th;
y(y<0)=0;
thNoNorm = th;
th = th/maxy;
y = sparse(y/maxy);  
