

global Nx Ny Sx SxMix Sc ScInh exInhBalance Sp
%global Sp NoR NoC NoM classOdorOverlap N4 S4 S4c templateOdor Jmax thMean thVar outlierThresh
global glomActMu glomActSig  thMean thVar classLevel1 classLevel2  mean_K std_K mean_K_inh
%global class1Color class2Color

Nx = 1000; %number of glomeruli
Ny = 10000; %number of piriform neurons
%N4 = 50;
exInhBalance = 1; %keeping it fixed
Sx = 0.1; %0.0513; %0.1; % sparseness% statement at right isn't true b/c of glomExpMin %.14; %fraction of glomeruli activated by an odor -- 14% exp gives 10% accounting for 95% of activity
SxMix = 1-sqrt(1-Sx); %approximate sparseness of components to yield an Sx-sparse resulting mix
Sc = 0.2;%.1; %.2; %.1; %.2; %prob of conn from glom to pir Number of excitatory connections
ScInh = 0.4;%0.2; %Number of inhibitory connections
Sp = 0.062; %.1; %.08; %.1;

glomActMu = .1;%0.07;%0.1; %"mu" of lognormal dist
glomActSig = .5;%0.7;%0.5;%"sig" of lognormal dist

thMean = 11.87;%8.5; %/Ny^2;%8.4; %piriform threshold
thVar = 0;%1.8;

classLevel2 = 0.7;
classLevel1 = 0.3;

No = 100;
mean_K=Nx*Sc;
mean_K_inh=Nx*ScInh;
% first make correlation matrix:
NoTot = 3*No;
Sclass = classLevel1*(ones(2*No)-eye(2*No))+eye(2*No);
Sclass(No+1:end,No+1:end) = classLevel2*(ones(No)-eye(No))+eye(No);
S = eye(NoTot);
S(No+1:end,No+1:end) = Sclass;

[glomRepTemp,odorSimilarity] = makeOdors('correlated',S,NoTot);

glomerulusRepRand = glomRepTemp(:,1:No);           %first group no overlap
similarityRand = -eps*(odorSimilarity(1:No)<0); 
glomerulusRepCorr1 = glomRepTemp(:,No+1:2*No);     % second group slight overlap
similarityClass1 = -2 + odorSimilarity(No+1:2*No);
glomerulusRepCorr2 = glomRepTemp(:,2*No+1:end);    %third group very overlap
similarityClass2 = -2 + odorSimilarity(2*No+1:end); 
% 
 

%combined for figure
glomerulusRep = [glomerulusRepRand,glomerulusRepCorr1,glomerulusRepCorr2];%,glomRepTempMix];
glomerulusRep=glomerulusRep-mean(glomerulusRep);

glomerulus_correlation=corr(glomerulusRep);

OB_Corr=glomerulus_correlation(triu(true(size(glomerulus_correlation)), 1));

ob_correlation=mean(OB_Corr);
 

[piriformRepRand,~,~,J] = makePiriform_Schaffer(glomerulusRepRand);
%   
% %graded
piriformRepClass1 = makePiriform_Schaffer(glomerulusRepCorr1,Sp,J);
piriformRepClass2 = makePiriform_Schaffer(glomerulusRepCorr2,Sp,J);
piriformRep = [piriformRepRand,piriformRepClass1,piriformRepClass2];%,piriformRepMix];
piriform=piriformRep +zeros(Ny,NoTot);

index12=find(J==1);
 index13=find(J==-0.5);
 an=zeros(Ny,Nx);
 ap=zeros(Ny,Nx);
 an(index13)=1;
 ap(index12)=1;
 d1=sum(ap');
 d2=sum(an');
 [a11,b11]=hist(d1,16);
 [a22,b22]=hist(d2,16);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure S5
 figure(5)
 plot(b11,a11/Ny,'b--')
 hold on
 plot(b22,a22/Ny,'r--')
%figure(2);imagesc(piriformRep);
% 
Corr_glomerulus1=[];Corr_glomerulus2=[];Corr_glomerulus3=[];Corr_glomerulus=[];

for m1 = 1:size(glomerulusRep,2) % Create correlations for each experimenter
 for m2 = m1:size(glomerulusRep,2) % Correlate against each experimenter
     
    % if (m1<=40 && m2<=40)
     if (m1<=No) && (m2<=No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));

  Corr_glomerulus1=[Corr_glomerulus1;Cor1_g,Cor1_pi];
     
     end
     %elseif (40<=m1<=80 && 40<=m2<=80)
     if (No<m1) && (m1<=2*No) && (No<m2) && (m2<=2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus2=[Corr_glomerulus2;Cor1_g,Cor1_pi];
     end
  
     %elseif (m1>=80 && m2 >=80)
      if (m1 >2*No) && (m2>2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus3=[Corr_glomerulus3;Cor1_g,Cor1_pi];
  
%        else 
%   Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
%   Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
%   Corr_glomerulus4=[Corr_glomerulus4;Cor1_g,Cor1_pi];
       end
     
 end
end
%%%%%%%%%%%%%%figure1B
Corr_glomerulus=[Corr_glomerulus1;Corr_glomerulus2;Corr_glomerulus3];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure5A part
figure(2)
 subplot(1,3,1)
hold on
plot(Corr_glomerulus3(:,1),Corr_glomerulus3(:,2),'.')
hold on
plot(Corr_glomerulus2(:,1),Corr_glomerulus2(:,2),'.')
plot(Corr_glomerulus1(:,1),Corr_glomerulus1(:,2),'.')



%%%% With variability

PC_data=[];
std_K=70;
%std_K
%%%%%%%%%%%%%%%%%Piriform
[piriformRepRand,~,~,J] = makePiriform(glomerulusRepRand);
% 
% %graded
piriformRepClass1 = makePiriform(glomerulusRepCorr1,Sp,J);
piriformRepClass2 = makePiriform(glomerulusRepCorr2,Sp,J);
piriformRep = [piriformRepRand,piriformRepClass1,piriformRepClass2];%,piriformRepMix];
piriform=piriformRep +zeros(Ny,NoTot);


piriform_correlation=corr(piriform);

PC_Corr=piriform_correlation(triu(true(size(piriform_correlation)), 1));

PC_correlation=nanmean(PC_Corr);
index12=find(J==1);
 index13=find(J==-0.5);
 an=zeros(Ny,Nx);
 ap=zeros(Ny,Nx);
 an(index13)=1;
 ap(index12)=1;
 d1=sum(ap');
 d2=sum(an');
 [a14,b14]=hist(d1,16);
 [a24,b24]=hist(d2,16);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure S5
 figure(5)
 plot(b14,a14/Ny,'g')
 hold on
 plot(b24,a24/Ny,'c')




%figure(2);imagesc(piriformRep);
% 
Corr_glomerulus1=[];Corr_glomerulus2=[];Corr_glomerulus3=[];Corr_glomerulus=[];

for m1 = 1:size(glomerulusRep,2) % Create correlations for each experimenter
 for m2 = m1:size(glomerulusRep,2) % Correlate against each experimenter
     
    % if (m1<=40 && m2<=40)
     if (m1<=No) && (m2<=No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));

  Corr_glomerulus1=[Corr_glomerulus1;Cor1_g,Cor1_pi];
     
     end
     %elseif (40<=m1<=80 && 40<=m2<=80)
     if (No<m1) && (m1<=2*No) && (No<m2) && (m2<=2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus2=[Corr_glomerulus2;Cor1_g,Cor1_pi];
     end
  
     %elseif (m1>=80 && m2 >=80)
      if (m1 >2*No) && (m2>2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus3=[Corr_glomerulus3;Cor1_g,Cor1_pi];
  
%        else 
%   Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
%   Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
%   Corr_glomerulus4=[Corr_glomerulus4;Cor1_g,Cor1_pi];
       end
     
 end
end
PC_data=[PC_data;std_K,PC_correlation,mean(Corr_glomerulus1(:,1)),mean(Corr_glomerulus1(:,2)),mean(Corr_glomerulus2(:,1)),mean(Corr_glomerulus2(:,2)),mean(Corr_glomerulus3(:,1)),mean(Corr_glomerulus3(:,2))];

Corr_glomerulus=[Corr_glomerulus1;Corr_glomerulus2;Corr_glomerulus3];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure5A part
figure(2)
 subplot(1,3,1)
 hold on
plot(Corr_glomerulus3(:,1),Corr_glomerulus3(:,2),'.')
hold on
plot(Corr_glomerulus2(:,1),Corr_glomerulus2(:,2),'.')
plot(Corr_glomerulus1(:,1),Corr_glomerulus1(:,2),'.')
%end
 plot([-0.2,1],[-0.2,1])
 xlabel('OB correlation','fontsize',10)
ylabel('PC correlation','fontsize',10);
 set(gca,'TickDir','out')
 a=gca;
 set(a,'box','off','color','none')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure5B
PC_correlation_exp=0.5359;
OB_correlation_exp=0.4119;
PC_data=[];
for std_K=1:10:151
%std_K
%%%%%%%%%%%%%%%%%Piriform
[piriformRepRand,~,~,J] = makePiriform(glomerulusRepRand);
% 
% %graded
piriformRepClass1 = makePiriform(glomerulusRepCorr1,Sp,J);
piriformRepClass2 = makePiriform(glomerulusRepCorr2,Sp,J);
piriformRep = [piriformRepRand,piriformRepClass1,piriformRepClass2];%,piriformRepMix];
piriform=piriformRep +zeros(Ny,NoTot);


piriform_correlation=corr(piriform);

PC_Corr=piriform_correlation(triu(true(size(piriform_correlation)), 1));

PC_correlation=nanmean(PC_Corr);

%figure(2);imagesc(piriformRep);
% 
Corr_glomerulus1=[];Corr_glomerulus2=[];Corr_glomerulus3=[];Corr_glomerulus=[];

for m1 = 1:size(glomerulusRep,2) % Create correlations for each experimenter
 for m2 = m1:size(glomerulusRep,2) % Correlate against each experimenter
     
    % if (m1<=40 && m2<=40)
     if (m1<=No) && (m2<=No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));

  Corr_glomerulus1=[Corr_glomerulus1;Cor1_g,Cor1_pi];
     
     end
     %elseif (40<=m1<=80 && 40<=m2<=80)
     if (No<m1) && (m1<=2*No) && (No<m2) && (m2<=2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus2=[Corr_glomerulus2;Cor1_g,Cor1_pi];
     end
  
     %elseif (m1>=80 && m2 >=80)
      if (m1 >2*No) && (m2>2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus3=[Corr_glomerulus3;Cor1_g,Cor1_pi];
  
%        else 
%   Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
%   Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
%   Corr_glomerulus4=[Corr_glomerulus4;Cor1_g,Cor1_pi];
       end
     
 end
end
PC_data=[PC_data;std_K/10,PC_correlation,mean(Corr_glomerulus1(:,1)),mean(Corr_glomerulus1(:,2)),mean(Corr_glomerulus2(:,1)),mean(Corr_glomerulus2(:,2)),mean(Corr_glomerulus3(:,1)),mean(Corr_glomerulus3(:,2))];
%%%%%%%%%%%%%%figure1B
Corr_glomerulus=[Corr_glomerulus1;Corr_glomerulus2;Corr_glomerulus3];
end
figure(2)
 subplot(1,3,2)
 
plot(PC_data(:,1),PC_data(:,4)-PC_data(:,3))
hold on
plot(PC_data(:,1),PC_data(:,6)-PC_data(:,5))
plot(PC_data(:,1),PC_data(:,8)-PC_data(:,7))

plot([0,std_K/10],[PC_correlation_exp-OB_correlation_exp,PC_correlation_exp-OB_correlation_exp],'k--')
plot([0,std_K/10],[0,0],'k')
xlabel('SD (K_{ex}) (%)','fontsize',10)
ylabel('<PC> - <OB> correlation','fontsize',10);
 set(gca,'TickDir','out')
 a=gca;
 set(a,'box','off','color','none')
 
 
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 5C
Ex_con=[0.1, 0.05, 0.02];
Inh_con=[0.2,0.1,0.04];
for ii=1:length(Ex_con)
Sc = Ex_con(ii);         %Number of excitatory connections
ScInh = Inh_con(ii);
mean_K=Nx*Sc;
mean_K_inh=Nx*ScInh;%Number of inhibitory connections
PC_correlation_exp=0.5359;
OB_correlation_exp=0.4119;
PC_data=[];
for std_K=1:10:151
%std_K
%%%%%%%%%%%%%%%%%Piriform
[piriformRepRand,~,~,J] = makePiriform(glomerulusRepRand);
% 
% %graded
piriformRepClass1 = makePiriform(glomerulusRepCorr1,Sp,J);
piriformRepClass2 = makePiriform(glomerulusRepCorr2,Sp,J);
piriformRep = [piriformRepRand,piriformRepClass1,piriformRepClass2];%,piriformRepMix];
piriform=piriformRep +zeros(Ny,NoTot);


piriform_correlation=corr(piriform);

PC_Corr=piriform_correlation(triu(true(size(piriform_correlation)), 1));

PC_correlation=nanmean(PC_Corr);

%figure(2);imagesc(piriformRep);
% 
Corr_glomerulus1=[];Corr_glomerulus2=[];Corr_glomerulus3=[];Corr_glomerulus=[];

for m1 = 1:size(glomerulusRep,2) % Create correlations for each experimenter
 for m2 = m1:size(glomerulusRep,2) % Correlate against each experimenter
     
    % if (m1<=40 && m2<=40)
     if (m1<=No) && (m2<=No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));

  Corr_glomerulus1=[Corr_glomerulus1;Cor1_g,Cor1_pi];
     
     end
     %elseif (40<=m1<=80 && 40<=m2<=80)
     if (No<m1) && (m1<=2*No) && (No<m2) && (m2<=2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus2=[Corr_glomerulus2;Cor1_g,Cor1_pi];
     end
  
     %elseif (m1>=80 && m2 >=80)
      if (m1 >2*No) && (m2>2*No)
  Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
  Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
  Corr_glomerulus3=[Corr_glomerulus3;Cor1_g,Cor1_pi];
  
%        else 
%   Cor1_g = corr(glomerulusRep(:,m1),glomerulusRep(:,m2));
%   Cor1_pi = corr(piriform(:,m1),piriform(:,m2));
%   Corr_glomerulus4=[Corr_glomerulus4;Cor1_g,Cor1_pi];
       end
     
 end
end
%std_K percentage= std_K*100/1000;
PC_data=[PC_data;std_K/10,PC_correlation,mean(Corr_glomerulus1(:,1)),mean(Corr_glomerulus1(:,2)),mean(Corr_glomerulus2(:,1)),mean(Corr_glomerulus2(:,2)),mean(Corr_glomerulus3(:,1)),mean(Corr_glomerulus3(:,2))];
%%%%%%%%%%%%%%figure1B
Corr_glomerulus=[Corr_glomerulus1;Corr_glomerulus2;Corr_glomerulus3];
end
figure(2)
 subplot(1,3,3)
 

hold on
plot(PC_data(:,1),PC_data(:,6)-PC_data(:,5))
% plot([0,std_K],[PC_correlation_exp-OB_correlation_exp,PC_correlation_exp-OB_correlation_exp],'k--')
% plot([0,std_K],[0,0],'k')
% xlabel('SD (K_{ex})(%)','fontsize',10)
% ylabel('<PC> - <OB> correlation','fontsize',10);
%  set(gca,'TickDir','out')
%  a=gca;
%  set(a,'box','off','color','none')
end
plot([0,std_K/10],[PC_correlation_exp-OB_correlation_exp,PC_correlation_exp-OB_correlation_exp],'k--')
plot([0,std_K/10],[0,0],'k')
plot([0,std_K/10],[0.4227,0.4227],'k')
xlabel('SD (K_{ex})(%)','fontsize',10)
ylabel('<PC> - <OB> correlation','fontsize',10);
 set(gca,'TickDir','out')
 a=gca;
 set(a,'box','off','color','none')
 
 



