function successRate =  generalLeav1OutDecoder(labels, data, labelIds, maxTrialNum, dist_type)
% run a leave one out analysis.
% input:
%   each row is one trial
%   labels: are the labels of the trial
%   features: are the samples of the label. features can be the firing rate
%   of several neurons
% number of trials for each label is not the same.
% number of samples for each label is not the same
% Algorithm:
%   select a trial and remove it from the matrix. keep it at testTrial
%   compute the center of each label
%   compute the distance between testTrial and the centers
%   set the label of the testTrial to the label it is most close too

if nargin < 5
    dist_type = 'euclidean';
end

if size(labels,1) > 1 & size(labels,2) > 1
    error('labels should be a columns vector')
end
if size(labels,2) > 1 labels = labels'; end

% if size(labels,1) ~=  size(feature,1)
%     error('labels and features should have the same number of samples')
% end

num_indxs = length(find(labels == labelIds(1)));

    s=0; c=0;
    for reps=1:50
        
        for labelTestIndx = labelIds
            leaveOneFr=NaN(1,num_indxs);
            labelCenterAll = NaN(length(labelIds),num_indxs);
            ll = 1; 
            for labelId = labelIds
                labelCenter=NaN(1,num_indxs);                                
                indx = find(labels == labelId)';
                jj=1;
                for ii=indx
                    fr = data(ii).features;
                    fr=fr(1:min(maxTrialNum,length(fr)));
                    if labelId == labelTestIndx
                        leaveOneIndx = randperm(length(fr),1);
                        leaveOneFr(jj) = fr(leaveOneIndx);
                        fr(leaveOneIndx) = []; % remove the sample
                    end
                    % compute the mean of the reamining samples
                    labelCenter(jj) = mean(fr);
                    jj = jj + 1;
                end
                labelCenterAll(ll,:) = labelCenter;
                ll = ll + 1;
            end
            %rall=[];
            dall = NaN(1,size(labelCenterAll,1));
            for i=1:size(labelCenterAll,1)
                d = pdist2(labelCenterAll(i,:), leaveOneFr, dist_type);
                dall(i) = d;
                %[r,p]=corrcoef(labelCenterAll(i,:), leaveOneFr);
                %rall(i) = r(1,2);
            end
            %[a,b]=max(rall);
            [a,b]=min(dall);
            if labelIds(b) == labelTestIndx
                s=s+1;
            end
            c=c+1;
        end
    end
successRate = s/c;
